celery -A djangoapp.apps.yoin beat --loglevel=info  --pidfile=/var/run/reservbeat.pid --schedule=/tmp/reservbeat-schedule &
celery -A djangoapp.apps.yoin worker -E --loglevel=info -n reserv --pidfile=/var/run/reservcelery.pid
