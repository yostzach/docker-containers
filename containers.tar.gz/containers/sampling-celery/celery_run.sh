celery -A djangoapp.apps.yoin beat --loglevel=info  --pidfile=/var/run/celerybeat.pid --schedule=/tmp/celerybeat-schedule &
celery -A djangoapp.apps.yoin worker -E --loglevel=info -n gerty --pidfile=/var/run/celery.pid
